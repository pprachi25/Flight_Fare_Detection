"""
╔══════════════════════════════════════════════════════╗
║     FLIGHTFARE.AI — FARE INTELLIGENCE PLATFORM       ║
║     Real-time ML predictions + Live Market Data      ║
║     Run: python app.py → http://localhost:5000       ║
╚══════════════════════════════════════════════════════╝
"""

from flask import Flask, render_template, request, jsonify
import pickle, json, numpy as np, os, logging, time, random, requests
from datetime import datetime, date, timedelta

app = Flask(__name__)

# ── Logging ──────────────────────────────────────────────────────────────────
logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s [%(levelname)s] %(message)s')
logger = logging.getLogger(__name__)

# ── Load model & assets ──────────────────────────────────────────────────────
BASE = os.path.dirname(__file__)

try:
    with open(os.path.join(BASE, 'model', 'model.pkl'), 'rb') as f:
        MODEL = pickle.load(f)
    with open(os.path.join(BASE, 'model', 'encodings.json')) as f:
        ENC = json.load(f)
    with open(os.path.join(BASE, 'model', 'metrics.json')) as f:
        METRICS = json.load(f)
    with open(os.path.join(BASE, 'model', 'stats.json')) as f:
        STATS = json.load(f)
    logger.info("Model and assets loaded successfully")
except Exception as e:
    logger.error(f"Failed to load model assets: {e}")
    raise

FEATURE_ORDER = ['airline', 'source_city', 'departure_time', 'stops',
                 'arrival_time', 'destination_city', 'class',
                 'duration', 'days_left', 'booking_window', 'is_peak']

# ── Valid values for input validation ────────────────────────────────────────
VALID_AIRLINES = {'AirAsia', 'Air_India', 'GO_FIRST', 'Indigo', 'SpiceJet', 'Vistara'}
VALID_CITIES = {'Delhi', 'Mumbai', 'Bangalore', 'Kolkata', 'Hyderabad', 'Chennai'}
VALID_TIMES = {'Early_Morning', 'Morning', 'Afternoon', 'Evening', 'Night', 'Late_Night'}
VALID_STOPS = {'zero', 'one', 'two_or_more'}
VALID_CLASSES = {'Economy', 'Business'}

# ── Dynamic Market State ─────────────────────────────────────────────────────
MARKET_STATE = {
    'demand_factor': 1.0,
    'fuel_factor': 1.04,
    'last_update': 0,
    'update_count': 0
}


def refresh_market_state():
    """Refresh market factors every 5 minutes to simulate live pricing."""
    now = time.time()
    if now - MARKET_STATE['last_update'] > 300:
        MARKET_STATE['demand_factor'] = 1.0 + random.uniform(-0.03, 0.03)
        MARKET_STATE['fuel_factor'] = 1.0 + random.uniform(0.02, 0.08)
        MARKET_STATE['last_update'] = now
        MARKET_STATE['update_count'] += 1
        logger.info(f"Market refresh #{MARKET_STATE['update_count']}: "
                    f"demand={MARKET_STATE['demand_factor']:.4f}, "
                    f"fuel={MARKET_STATE['fuel_factor']:.4f}")


def get_season_label(month):
    if month in [10, 11]:
        return 'Festival Season (Diwali)'
    elif month in [12, 1]:
        return 'Winter Holidays'
    elif month in [4, 5]:
        return 'Summer Peak'
    elif month in [7, 8]:
        return 'Monsoon (Low)'
    elif month in [2, 3]:
        return 'Spring'
    else:
        return 'Regular Season'


def get_dynamic_factors(travel_date_str, dep_time):
    """Calculate dynamic pricing adjustment factors."""
    refresh_market_state()
    try:
        travel_date = datetime.strptime(travel_date_str, '%Y-%m-%d').date()
    except Exception:
        travel_date = date.today() + timedelta(days=15)

    # Day of week factor
    day = travel_date.weekday()
    dow_factors = {0: 0.97, 1: 0.95, 2: 0.98, 3: 1.00, 4: 1.05, 5: 1.12, 6: 1.08}
    dow_factor = dow_factors.get(day, 1.0)

    # Seasonal factor
    month = travel_date.month
    seasonal_map = {1: 1.15, 2: 0.98, 3: 0.98, 4: 1.12, 5: 1.12,
                    6: 1.0, 7: 0.92, 8: 0.92, 9: 1.0, 10: 1.18, 11: 1.18, 12: 1.15}
    seasonal = seasonal_map.get(month, 1.0)

    # Time of day factor
    time_factors = {
        'Early_Morning': 0.92, 'Morning': 1.08, 'Afternoon': 1.00,
        'Evening': 1.10, 'Night': 0.95, 'Late_Night': 0.88
    }
    time_factor = time_factors.get(dep_time, 1.0)

    return {
        'day_of_week': {'factor': round(dow_factor, 2),
                        'label': travel_date.strftime('%A')},
        'seasonal':    {'factor': round(seasonal, 2),
                        'label': get_season_label(month)},
        'demand':      {'factor': round(MARKET_STATE['demand_factor'], 4),
                        'label': 'Live Demand'},
        'fuel':        {'factor': round(MARKET_STATE['fuel_factor'], 4),
                        'label': 'Fuel Surcharge'},
        'time_of_day': {'factor': round(time_factor, 2),
                        'label': dep_time.replace('_', ' ')},
    }


# ── Routes ───────────────────────────────────────────────────────────────────
@app.route('/')
def index():
    return render_template('index.html', metrics=METRICS, stats=STATS)


@app.route('/health')
def health():
    return jsonify({'status': 'healthy', 'model_loaded': MODEL is not None,
                    'timestamp': datetime.now().isoformat()})


@app.route('/predict', methods=['POST'])
def predict():
    try:
        data = request.get_json()
        if not data:
            return jsonify({'success': False, 'error': 'No data provided'}), 400

        # ── Validate inputs ──
        errors = []
        if data.get('airline') not in VALID_AIRLINES:
            errors.append(f"Invalid airline: {data.get('airline')}")
        if data.get('source_city') not in VALID_CITIES:
            errors.append(f"Invalid source city")
        if data.get('destination_city') not in VALID_CITIES:
            errors.append(f"Invalid destination city")
        if data.get('source_city') == data.get('destination_city'):
            errors.append("Source and destination cannot be the same")
        if data.get('departure_time') not in VALID_TIMES:
            errors.append(f"Invalid departure time")
        if data.get('arrival_time') not in VALID_TIMES:
            errors.append(f"Invalid arrival time")
        if data.get('stops') not in VALID_STOPS:
            errors.append(f"Invalid stops value")
        if data.get('class') not in VALID_CLASSES:
            errors.append(f"Invalid class")
        if errors:
            return jsonify({'success': False, 'error': '; '.join(errors)}), 400

        # Encode categoricals
        def enc(col, val):
            return ENC[col].get(str(val), 0)

        days_left = max(1, min(49, int(data['days_left'])))
        duration  = max(0.5, min(50, float(data['duration'])))
        dep_time  = data['departure_time']
        passengers = max(1, min(9, int(data.get('passengers', 1))))

        booking_window = (3 if days_left <= 7 else
                          2 if days_left <= 14 else
                          1 if days_left <= 30 else 0)
        is_peak = 1 if dep_time in ['Early_Morning', 'Morning'] else 0

        features = np.array([[
            enc('airline',          data['airline']),
            enc('source_city',      data['source_city']),
            enc('departure_time',   dep_time),
            enc('stops',            data['stops']),
            enc('arrival_time',     data['arrival_time']),
            enc('destination_city', data['destination_city']),
            enc('class',            data['class']),
            duration,
            days_left,
            booking_window,
            is_peak,
        ]])

        # ML base prediction
        base_price = float(MODEL.predict(features)[0])
        base_price = max(1105, min(123071, base_price))

        # Confidence interval from individual trees
        tree_preds = np.array([t.predict(features)[0]
                               for t in MODEL.estimators_[:, 0]])
        ci_lo = float(np.percentile(tree_preds, 5))
        ci_hi = float(np.percentile(tree_preds, 95))

        # Dynamic pricing adjustments
        travel_date = data.get('travel_date', '')
        factors = get_dynamic_factors(travel_date, dep_time)

        combined_factor = 1.0
        for val in factors.values():
            combined_factor *= val['factor']

        market_price = base_price * combined_factor
        market_price = max(1105, min(200000, market_price))
        total_price  = market_price * passengers

        category = ('Budget' if market_price < 8000 else
                    'Mid-Range' if market_price < 25000 else 'Premium')

        logger.info(f"Prediction: {data['source_city']}->{data['destination_city']} "
                    f"| Base: {base_price:,.0f} | Market: {market_price:,.0f} "
                    f"| {passengers} pax | Factor: {combined_factor:.4f}")

        return jsonify({
            'success': True,
            'base_price':      round(base_price, 2),
            'market_price':    round(market_price, 2),
            'total_price':     round(total_price, 2),
            'passengers':      passengers,
            'ci_lo':           round(max(1105, ci_lo * combined_factor), 2),
            'ci_hi':           round(min(200000, ci_hi * combined_factor), 2),
            'category':        category,
            'factors':         factors,
            'combined_factor': round(combined_factor, 4),
            'timestamp':       datetime.now().strftime('%H:%M:%S'),
        })

    except Exception as e:
        logger.error(f"Prediction error: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/market-pulse')
def market_pulse():
    """Returns current market state for auto-refresh."""
    refresh_market_state()
    return jsonify({
        'success': True,
        'demand_factor': round(MARKET_STATE['demand_factor'], 4),
        'fuel_factor':   round(MARKET_STATE['fuel_factor'], 4),
        'market_trend':  'up' if MARKET_STATE['demand_factor'] > 1.0 else 'down',
        'update_count':  MARKET_STATE['update_count'],
        'timestamp':     datetime.now().strftime('%H:%M:%S'),
    })


@app.route('/convert')
def convert():
    """Fetch live exchange rates from Frankfurter API (no key required)."""
    try:
        resp = requests.get(
            'https://api.frankfurter.dev/v2/rates?base=INR&quotes=USD,EUR,GBP',
            timeout=5
        )
        data = resp.json()
        rates = {}
        if 'rates' in data:
            if isinstance(data['rates'], list):
                for r in data['rates']:
                    rates[r.get('quote', '')] = r.get('rate', 0)
            elif isinstance(data['rates'], dict):
                rates = data['rates']
        return jsonify({
            'success': True, 'rates': rates,
            'date': data.get('date', ''),
            'source': 'Frankfurter API (ECB)'
        })
    except Exception as e:
        logger.warning(f"Currency API fallback: {e}")
        return jsonify({
            'success': True,
            'rates': {'USD': 0.01187, 'EUR': 0.01095, 'GBP': 0.00942},
            'date': date.today().isoformat(),
            'source': 'Cached (fallback)'
        })


@app.route('/weather/<city>')
def weather(city):
    """Fetch current weather from wttr.in (no key required)."""
    city_map = {
        'Delhi': 'New+Delhi', 'Mumbai': 'Mumbai', 'Bangalore': 'Bengaluru',
        'Kolkata': 'Kolkata', 'Hyderabad': 'Hyderabad', 'Chennai': 'Chennai'
    }
    query_city = city_map.get(city, city)
    try:
        resp = requests.get(
            f'https://wttr.in/{query_city}?format=j1',
            timeout=5, headers={'User-Agent': 'FlightFare/1.0'}
        )
        data = resp.json()
        cur = data['current_condition'][0]
        desc = cur['weatherDesc'][0]['value']
        return jsonify({
            'success': True, 'city': city,
            'temp_c': int(cur['temp_C']),
            'feels_like': int(cur['FeelsLikeC']),
            'humidity': int(cur['humidity']),
            'description': desc,
            'wind_kmph': int(cur['windspeedKmph']),
            'icon': _weather_icon(desc),
        })
    except Exception as e:
        logger.warning(f"Weather API error for {city}: {e}")
        return jsonify({'success': False, 'city': city})


def _weather_icon(desc):
    d = desc.lower()
    if 'sunny' in d or 'clear' in d: return '☀️'
    if 'partly cloudy' in d:          return '⛅'
    if 'cloudy' in d or 'overcast' in d: return '☁️'
    if 'rain' in d or 'drizzle' in d: return '🌧️'
    if 'thunder' in d:                return '⛈️'
    if 'snow' in d:                   return '❄️'
    if 'fog' in d or 'mist' in d or 'haze' in d: return '🌫️'
    return '🌤️'


@app.route('/stats')
def stats():
    return jsonify(STATS)


@app.route('/metrics')
def metrics():
    return jsonify(METRICS)


# ── Run ──────────────────────────────────────────────────────────────────────
if __name__ == '__main__':
    debug_mode = os.getenv('FLASK_DEBUG', 'true').lower() == 'true'
    port = int(os.getenv('PORT', 5000))
    print("\n" + "="*55)
    print("  FLIGHTFARE.AI - FARE INTELLIGENCE PLATFORM")
    print(f"  Open browser: http://localhost:{port}")
    print(f"  Debug mode: {debug_mode}")
    print("="*55 + "\n")
    app.run(debug=debug_mode, host='0.0.0.0', port=port)
