/* ═══════════════════════════════════════════════════════
   FLIGHTFARE.AI — MAIN JS
   ═══════════════════════════════════════════════════════ */

/* ── STATE ─────────────────────────────────────────────── */
let lastPrediction = null;
let lastPayload = null;
let refreshInterval = null;
let refreshCountdown = 60;
let exchangeRates = null;
let currentCurrency = 'INR';

/* ── PARTICLES BACKGROUND ──────────────────────────────── */
(function initParticles() {
  const canvas = document.getElementById('particles');
  const ctx = canvas.getContext('2d');
  let W, H, particles = [];
  function resize() { W = canvas.width = window.innerWidth; H = canvas.height = window.innerHeight; }
  function Particle() { this.reset(); }
  Particle.prototype.reset = function () {
    this.x = Math.random() * W; this.y = Math.random() * H;
    this.r = Math.random() * 1.2 + 0.3; this.a = Math.random() * 0.4 + 0.05;
    this.vx = (Math.random() - 0.5) * 0.3; this.vy = (Math.random() - 0.5) * 0.3;
    this.life = Math.random() * 200 + 100; this.age = 0;
  };
  Particle.prototype.update = function () {
    this.x += this.vx; this.y += this.vy; this.age++;
    if (this.age > this.life || this.x < 0 || this.x > W || this.y < 0 || this.y > H) this.reset();
  };
  resize();
  for (let i = 0; i < 80; i++) particles.push(new Particle());
  function draw() {
    ctx.clearRect(0, 0, W, H);
    particles.forEach(p => {
      p.update(); ctx.beginPath(); ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(0, 212, 255, ${p.a})`; ctx.fill();
    });
    for (let i = 0; i < particles.length; i++) {
      for (let j = i + 1; j < particles.length; j++) {
        const dx = particles[i].x - particles[j].x, dy = particles[i].y - particles[j].y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < 100) {
          ctx.beginPath(); ctx.moveTo(particles[i].x, particles[i].y);
          ctx.lineTo(particles[j].x, particles[j].y);
          ctx.strokeStyle = `rgba(0,212,255,${0.04 * (1 - dist / 100)})`;
          ctx.lineWidth = 0.5; ctx.stroke();
        }
      }
    }
    requestAnimationFrame(draw);
  }
  draw(); window.addEventListener('resize', resize);
})();

/* ── ANIMATE BARS ON LOAD ──────────────────────────────── */
window.addEventListener('DOMContentLoaded', () => {
  setTimeout(() => {
    document.querySelectorAll('.bar-fill, .inline-bar-fill, .cc-bar').forEach(b => {
      const tw = b.style.getPropertyValue('--tw') || b.style.getPropertyValue('--target-width') || b.style.getPropertyValue('--bw');
      if (tw) b.style.width = tw;
    });
  }, 400);
  initDatePicker();
  initSameCityPrevention();
  fetchExchangeRates();
});

/* ── TOAST NOTIFICATION SYSTEM ─────────────────────────── */
function showToast(message, type = 'info', duration = 4000) {
  const container = document.getElementById('toastContainer');
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.textContent = message;
  container.appendChild(toast);
  setTimeout(() => { toast.style.opacity = '0'; toast.style.transform = 'translateX(60px)'; toast.style.transition = 'all 0.3s'; }, duration - 300);
  setTimeout(() => toast.remove(), duration);
}

/* ── DATE PICKER SETUP ─────────────────────────────────── */
function initDatePicker() {
  const dateInput = document.getElementById('travel_date');
  const hint = document.getElementById('dateHint');
  const today = new Date();
  const minDate = new Date(today); minDate.setDate(today.getDate() + 1);
  const maxDate = new Date(today); maxDate.setDate(today.getDate() + 49);
  dateInput.min = formatDate(minDate);
  dateInput.max = formatDate(maxDate);
  // Default to 15 days from now
  const defaultDate = new Date(today); defaultDate.setDate(today.getDate() + 15);
  dateInput.value = formatDate(defaultDate);
  updateDateHint();
  dateInput.addEventListener('change', updateDateHint);
}

function formatDate(d) {
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}

function getDaysLeft() {
  const dateInput = document.getElementById('travel_date');
  if (!dateInput.value) return 15;
  const travel = new Date(dateInput.value);
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const diff = Math.ceil((travel - today) / (1000 * 60 * 60 * 24));
  return Math.max(1, Math.min(49, diff));
}

function updateDateHint() {
  const days = getDaysLeft();
  const hint = document.getElementById('dateHint');
  if (days <= 7) hint.innerHTML = `<span style="color:#EF4444">⚠ ${days} days away — Prices are HIGH</span>`;
  else if (days <= 21) hint.innerHTML = `<span style="color:#F59E0B">${days} days away — Moderate pricing</span>`;
  else hint.innerHTML = `<span style="color:#10B981">✓ ${days} days away — Best price window</span>`;
}

/* ── SAME CITY PREVENTION ──────────────────────────────── */
function initSameCityPrevention() {
  const src = document.getElementById('source');
  const dst = document.getElementById('dest');
  function check() {
    if (src.value === dst.value) {
      showToast('Source and destination cannot be the same city', 'error');
      // Auto-switch destination to next available
      const options = Array.from(dst.options);
      const next = options.find(o => o.value !== src.value);
      if (next) dst.value = next.value;
    }
  }
  src.addEventListener('change', check);
  dst.addEventListener('change', check);
}

/* ── RANGE SLIDER HELPER ───────────────────────────────── */
function updateRange(id, displayId, suffix) {
  document.getElementById(displayId).textContent = document.getElementById(id).value + suffix;
}

/* ── CITY CODES MAP ────────────────────────────────────── */
const CITY_CODE = { Delhi: 'DEL', Mumbai: 'BOM', Bangalore: 'BLR', Kolkata: 'CCU', Hyderabad: 'HYD', Chennai: 'MAA' };

/* ── ANIMATED NUMBER ───────────────────────────────────── */
function animateNumber(el, target, prefix = '₹', duration = 900) {
  const startTime = performance.now();
  function step(now) {
    const p = Math.min((now - startTime) / duration, 1);
    const ease = 1 - Math.pow(1 - p, 3);
    const val = Math.round(ease * target);
    el.textContent = prefix + val.toLocaleString('en-IN');
    if (p < 1) requestAnimationFrame(step);
  }
  requestAnimationFrame(step);
}

/* ── EXCHANGE RATES ────────────────────────────────────── */
async function fetchExchangeRates() {
  try {
    const res = await fetch('/convert');
    const data = await res.json();
    if (data.success) {
      exchangeRates = data.rates;
      const srcEl = document.getElementById('currSource');
      if (srcEl) srcEl.textContent = data.source;
    }
  } catch (e) { console.warn('Currency fetch failed:', e); }
}

function convertPrice(inrPrice, currency) {
  if (currency === 'INR' || !exchangeRates) return { amount: inrPrice, symbol: '₹' };
  const symbols = { USD: '$', EUR: '€', GBP: '£' };
  const rate = exchangeRates[currency] || 1;
  return { amount: Math.round(inrPrice * rate * 100) / 100, symbol: symbols[currency] || currency };
}

function updateDisplayedPrices() {
  if (!lastPrediction) return;
  const d = lastPrediction;
  const c = currentCurrency;
  const base = convertPrice(d.base_price, c);
  const market = convertPrice(d.market_price, c);
  const lo = convertPrice(d.ci_lo, c);
  const hi = convertPrice(d.ci_hi, c);
  document.getElementById('basePriceDisplay').textContent = base.symbol + Math.round(base.amount).toLocaleString('en-IN');
  animateNumber(document.getElementById('marketPriceDisplay'), Math.round(market.amount), market.symbol, 600);
  document.getElementById('priceCI').textContent = `Range: ${lo.symbol}${Math.round(lo.amount).toLocaleString('en-IN')} – ${hi.symbol}${Math.round(hi.amount).toLocaleString('en-IN')}`;
  if (d.passengers > 1) {
    const total = convertPrice(d.total_price, c);
    document.getElementById('totalPrice').textContent = total.symbol + Math.round(total.amount).toLocaleString('en-IN');
  }
}

/* ── CURRENCY TOGGLE ───────────────────────────────────── */
document.addEventListener('click', (e) => {
  if (e.target.classList.contains('curr-btn')) {
    document.querySelectorAll('.curr-btn').forEach(b => b.classList.remove('active'));
    e.target.classList.add('active');
    currentCurrency = e.target.dataset.curr;
    updateDisplayedPrices();
  }
});

/* ── WEATHER FETCH ─────────────────────────────────────── */
async function fetchWeather(city) {
  const card = document.getElementById('weatherCard');
  try {
    const res = await fetch(`/weather/${encodeURIComponent(city)}`);
    const data = await res.json();
    if (data.success) {
      document.getElementById('weatherIcon').textContent = data.icon;
      document.getElementById('weatherTemp').textContent = data.temp_c + '°C';
      document.getElementById('weatherDesc').textContent = data.description + ' in ' + data.city;
      document.getElementById('weatherFeels').textContent = 'Feels like ' + data.feels_like + '°C';
      document.getElementById('weatherHumidity').textContent = 'Humidity ' + data.humidity + '%';
      document.getElementById('weatherWind').textContent = 'Wind ' + data.wind_kmph + ' km/h';
      card.style.display = 'block';
    }
  } catch (e) { console.warn('Weather fetch failed:', e); }
}

/* ── PRICE BREAKDOWN ───────────────────────────────────── */
function renderBreakdown(data) {
  const list = document.getElementById('breakdownList');
  const factors = data.factors;
  let html = `<div class="bd-row"><span class="bd-label">🤖 ML Base Prediction</span><span class="bd-value">₹${Math.round(data.base_price).toLocaleString('en-IN')}</span></div>`;
  const factorOrder = ['day_of_week', 'seasonal', 'time_of_day', 'demand', 'fuel'];
  const icons = { day_of_week: '📅', seasonal: '🗓️', time_of_day: '🕐', demand: '📈', fuel: '⛽' };
  factorOrder.forEach(key => {
    const f = factors[key];
    if (!f) return;
    const pct = ((f.factor - 1) * 100).toFixed(1);
    const cls = f.factor > 1.005 ? 'up' : f.factor < 0.995 ? 'down' : 'neutral';
    const sign = f.factor >= 1 ? '+' : '';
    html += `<div class="bd-row"><span class="bd-label">${icons[key]} ${f.label}</span><span class="bd-factor ${cls}">${sign}${pct}%</span></div>`;
  });
  html += `<div class="bd-row" style="margin-top:6px;padding-top:10px;border-top:1px solid rgba(0,212,255,.15)"><span class="bd-label" style="color:var(--accent)">✈ Live Market Price</span><span class="bd-value" style="color:var(--accent);font-size:14px">₹${Math.round(data.market_price).toLocaleString('en-IN')}</span></div>`;
  list.innerHTML = html;
}

/* ── AUTO-REFRESH ──────────────────────────────────────── */
function startAutoRefresh() {
  if (refreshInterval) clearInterval(refreshInterval);
  refreshCountdown = 60;
  const timerEl = document.getElementById('refreshTimer');
  refreshInterval = setInterval(async () => {
    refreshCountdown--;
    if (timerEl) timerEl.textContent = `Auto-refresh in ${refreshCountdown}s`;
    if (refreshCountdown <= 0) {
      refreshCountdown = 60;
      if (lastPayload) {
        try {
          const res = await fetch('/predict', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(lastPayload) });
          const data = await res.json();
          if (data.success) {
            lastPrediction = data;
            updateDisplayedPrices();
            renderBreakdown(data);
            document.getElementById('marketPriceDisplay').style.animation = 'priceFlash 0.8s ease';
            setTimeout(() => { document.getElementById('marketPriceDisplay').style.animation = ''; }, 800);
            const liveLabel = document.getElementById('liveLabel');
            if (liveLabel) liveLabel.textContent = 'UPDATED ' + data.timestamp;
            setTimeout(() => { if (liveLabel) liveLabel.textContent = 'LIVE'; }, 3000);
          }
        } catch (e) { console.warn('Auto-refresh failed:', e); }
      }
    }
  }, 1000);
}

/* ── PREDICT FORM SUBMIT ───────────────────────────────── */
document.getElementById('predictForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const btn = document.getElementById('predictBtn');
  btn.classList.add('loading');
  btn.querySelector('.btn-text').textContent = 'ANALYZING MARKET...';
  btn.querySelector('.btn-icon').textContent = '⏳';

  const payload = {
    airline: document.getElementById('airline').value,
    source_city: document.getElementById('source').value,
    destination_city: document.getElementById('dest').value,
    departure_time: document.getElementById('dep_time').value,
    arrival_time: document.getElementById('arr_time').value,
    stops: document.getElementById('stops').value,
    class: document.getElementById('cls').value,
    duration: parseFloat(document.getElementById('duration').value),
    days_left: getDaysLeft(),
    passengers: parseInt(document.getElementById('passengers').value),
    travel_date: document.getElementById('travel_date').value,
  };

  // Validate same city
  if (payload.source_city === payload.destination_city) {
    showToast('Source and destination cannot be the same', 'error');
    btn.classList.remove('loading');
    btn.querySelector('.btn-text').textContent = 'GET LIVE FARE';
    btn.querySelector('.btn-icon').textContent = '⚡';
    return;
  }

  try {
    const res = await fetch('/predict', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
    const data = await res.json();
    if (!data.success) throw new Error(data.error);

    lastPrediction = data;
    lastPayload = payload;
    currentCurrency = 'INR';
    document.querySelectorAll('.curr-btn').forEach(b => b.classList.remove('active'));
    document.querySelector('.curr-btn[data-curr="INR"]').classList.add('active');

    // Show result section
    const section = document.getElementById('resultSection');
    section.classList.remove('show');
    void section.offsetWidth;
    section.classList.add('show');

    // Prices
    document.getElementById('basePriceDisplay').textContent = '₹' + Math.round(data.base_price).toLocaleString('en-IN');
    animateNumber(document.getElementById('marketPriceDisplay'), Math.round(data.market_price));
    document.getElementById('priceCI').textContent = `Range: ₹${Math.round(data.ci_lo).toLocaleString('en-IN')} – ₹${Math.round(data.ci_hi).toLocaleString('en-IN')}`;

    // Total row
    if (data.passengers > 1) {
      document.getElementById('totalRow').style.display = 'flex';
      document.getElementById('paxCount').textContent = data.passengers;
      animateNumber(document.getElementById('totalPrice'), Math.round(data.total_price));
    } else {
      document.getElementById('totalRow').style.display = 'none';
    }

    // Badge
    const badgeEl = document.getElementById('fareBadge');
    const badgeMap = { Budget: ['badge-budget', '🟢 Budget Friendly'], 'Mid-Range': ['badge-mid', '🟡 Mid Range'], Premium: ['badge-premium', '🔴 Premium'] };
    const [cls, label] = badgeMap[data.category] || ['badge-mid', '🟡 Mid Range'];
    badgeEl.className = 'fare-badge ' + cls;
    badgeEl.textContent = label;

    // Route
    const src = payload.source_city, dst = payload.destination_city;
    document.getElementById('srcCode').textContent = CITY_CODE[src] || src.slice(0, 3).toUpperCase();
    document.getElementById('dstCode').textContent = CITY_CODE[dst] || dst.slice(0, 3).toUpperCase();
    document.getElementById('srcName').textContent = src;
    document.getElementById('dstName').textContent = dst;
    const stopsLabel = { zero: 'Non-stop', one: '1 Stop', two_or_more: '2+ Stops' };
    document.getElementById('routeMeta').textContent = `${payload.duration}h · ${stopsLabel[payload.stops]}`;

    // Quick facts
    document.getElementById('qf-airline').textContent = payload.airline.replace(/_/g, ' ');
    document.getElementById('qf-class').textContent = payload.class;
    document.getElementById('qf-stops').textContent = stopsLabel[payload.stops];
    const travelDate = new Date(payload.travel_date);
    document.getElementById('qf-date').textContent = travelDate.toLocaleDateString('en-IN', { day: 'numeric', month: 'short' });

    // Breakdown
    renderBreakdown(data);

    // Weather
    fetchWeather(dst);

    // Start auto-refresh
    startAutoRefresh();

    // Scroll to result
    section.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    showToast(`Fare predicted: ₹${Math.round(data.market_price).toLocaleString('en-IN')} · Updated ${data.timestamp}`, 'success');

  } catch (err) {
    showToast('Prediction failed: ' + err.message, 'error');
  } finally {
    btn.classList.remove('loading');
    btn.querySelector('.btn-text').textContent = 'GET LIVE FARE';
    btn.querySelector('.btn-icon').textContent = '⚡';
  }
});
